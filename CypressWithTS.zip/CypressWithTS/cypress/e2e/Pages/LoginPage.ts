/// <reference types="cypress" />

class LoginPage {
    /** object locators for home page */
  
    txtUsername = "input[name='userName']";
    txtPassword = "input[name='password']";
    btnLogin = "input[name='submit']";
    
    //Enter username
    enterUsername() {
      cy.get(this.txtUsername).type("kdimuthu")
    }

     //Enter password
     enterPassword() {
        cy.get(this.txtPassword).type("Dimuthu@123")
      }

      //Click login
     clickLogin() {
        cy.get(this.btnLogin).click()
      }
  
}
  export default LoginPage;
  