
import LoginPage from "../Pages/LoginPage"

/// <reference types="cypress" />

describe('First Test' , () =>{

    it('Login' , () =>{

        cy.visit("https://demo.guru99.com/test/newtours/")
    })

    //Login to system (page object model)
  it.only("Implementing Page Object Model", () => {
    
    cy.visit("https://demo.guru99.com/test/newtours/")
    const _LoginPage = new LoginPage();
    //Login
    _LoginPage.enterUsername();
    _LoginPage.enterPassword()
    _LoginPage.clickLogin()
   
  });

})